﻿namespace Test
{
    public class Class1
    {

    }
}